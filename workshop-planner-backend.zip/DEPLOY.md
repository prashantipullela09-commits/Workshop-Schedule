# Get a shareable link (about 10 minutes)

1. Create a free GitHub account, make a new empty repository, and upload every file from this folder
   (server.js, package.json, render.yaml, public/index.html, README.md, Dockerfile).
2. Sign up at render.com, click New > Blueprint, connect that GitHub repository.
   Render reads render.yaml and asks for two values:
   - ADMIN_PASSWORD: password for you (can edit everything)
   - OPS_PASSWORD: password for Program Ops (can add dates, times, themes)
3. Click Apply. After a couple of minutes you get a link like https://workshop-planner.onrender.com
4. Open it, click "Sign in to edit", sign in as Admin, go to Admin tab, click Import, then click Open month.
5. Share the link with stakeholders. They can view without any password and see changes within about 5 seconds.
   Give the Ops password only to people who should add dates.

Notes: the starter plan plus a 1 GB disk is a small monthly cost; a free plan loses data on restart.
