# Innovators Workshop Planner (with backend)

Zero dependencies. Needs Node 22.5+ (uses built-in SQLite). Run:

    ADMIN_PASSWORD=choose-one OPS_PASSWORD=choose-another SECRET=long-random-text npm start

Open http://localhost:3000. Everyone can view. "Sign in to edit" takes the Admin or Program Ops password.
First time: sign in as Admin, open Admin tab, click Import (42 campuses + 12 instructors), then Open month.

## What the server enforces
- One instructor cannot have two workshops on the same date (checked in one function, plus a database unique index, so simultaneous saves cannot both win).
- Roles: Admin edits everything. Program Ops edits workshops (dates) and themes only. Viewers are read-only.
- Status is derived: Scheduled only when a workshop has a date and both from/to times.

## Deploy (so others can edit via a link)
Any host that runs Node or Docker works (Render, Railway, Fly.io, an office server).
1. Push this folder to a Git repo, create a Web Service, start command `npm start`.
2. Set env vars ADMIN_PASSWORD, OPS_PASSWORD, SECRET.
3. Attach a persistent disk and set DB_FILE to a path on it (e.g. /data/data.sqlite), or data resets on redeploy.
4. Share the URL and the Ops password with your team.

API: GET /api/state, PUT/DELETE /api/<instructors|campuses|months|workshops>/<id>, POST /api/login.
