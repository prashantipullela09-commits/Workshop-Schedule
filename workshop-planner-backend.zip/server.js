// Innovators Workshop Planner - backend. Zero dependencies: Node 22.5+ (built-in node:http, node:sqlite).
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = process.env.PORT || 3000;
const DB_FILE = process.env.DB_FILE || path.join(__dirname, 'data.sqlite');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';   // CHANGE in production
const OPS_PASSWORD = process.env.OPS_PASSWORD || 'ops123';         // CHANGE in production
const SECRET = process.env.SECRET || 'change-this-secret';

const db = new DatabaseSync(DB_FILE);
const COLS = ['instructors', 'campuses', 'months', 'workshops'];
for (const c of COLS) db.exec(`CREATE TABLE IF NOT EXISTS ${c} (id TEXT PRIMARY KEY, data TEXT NOT NULL)`);
// Workshops get real columns too so the database itself can enforce the conflict rule.
db.exec(`CREATE TABLE IF NOT EXISTS slot (workshop_id TEXT PRIMARY KEY, instructor_id TEXT NOT NULL, date TEXT NOT NULL)`);
db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS uq_instructor_date ON slot(instructor_id, date)`);

const ord = y => (y === 1 ? '1st' : '2nd');
const fmt = d => { const x = new Date(d + 'T00:00:00Z'); return x.getUTCDate() + ' ' + x.toLocaleString('en-IN', { month: 'short', timeZone: 'UTC' }); };
const get = (col, id) => { const r = db.prepare(`SELECT data FROM ${col} WHERE id=?`).get(id); return r ? JSON.parse(r.data) : null; };

// ---- THE one validation function: used for every create / edit / carry-over ----
function validateWorkshop(w) {
  if (!w.id || !w.campus || ![1, 2].includes(w.year) || !w.month) return 'Workshop needs id, campus, year and month.';
  if (w.date && !/^\d{4}-\d{2}-\d{2}$/.test(w.date)) return 'Invalid date.';
  if (w.date && w.instructor_id) {
    const o = db.prepare('SELECT workshop_id FROM slot WHERE instructor_id=? AND date=? AND workshop_id<>?').get(w.instructor_id, w.date, w.id);
    if (o) {
      const other = get('workshops', o.workshop_id) || {};
      const inst = (get('instructors', w.instructor_id) || {}).name || 'Instructor';
      const camp = (get('campuses', other.campus) || {}).name || other.campus;
      return `${inst} is already scheduled at ${camp} (${ord(other.year)} Year) on ${fmt(w.date)}.`;
    }
  }
  return null;
}

// ---- auth: signed role tokens ----
const sign = s => crypto.createHmac('sha256', SECRET).update(s).digest('hex');
const makeToken = role => { const p = role + '.' + (Date.now() + 12 * 3600e3); return p + '.' + sign(p); };
function roleOf(req) {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  const [role, exp, sig] = t.split('.');
  if (!sig || sign(role + '.' + exp) !== sig || Date.now() > +exp) return 'viewer';
  return role;
}
const canWrite = (role, col) => role === 'admin' || (role === 'ops' && (col === 'workshops' || col === 'months'));

const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise((ok, no) => { let b = ''; req.on('data', c => { b += c; if (b.length > 1e6) req.destroy(); }); req.on('end', () => { try { ok(b ? JSON.parse(b) : {}); } catch (e) { no(e); } }); });

function saveDoc(col, id, doc) {
  doc.id = id;
  if (col === 'workshops') {
    const err = validateWorkshop(doc);
    if (err) return err;
    doc.status = (doc.date && doc.start_time && doc.end_time) ? 'Scheduled' : 'Unscheduled';   // Scheduled needs date + from/to time
  }
  try {
    db.exec('BEGIN');
    db.prepare(`INSERT INTO ${col}(id,data) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data`).run(id, JSON.stringify(doc));
    if (col === 'workshops') {
      db.prepare('DELETE FROM slot WHERE workshop_id=?').run(id);
      if (doc.date && doc.instructor_id) db.prepare('INSERT INTO slot VALUES(?,?,?)').run(id, doc.instructor_id, doc.date);
    }
    db.exec('COMMIT');
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch {}
    return 'Conflict: that instructor is already booked on this date.';   // unique index backstop (race-proof)
  }
  return null;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname === '/api/login' && req.method === 'POST') {
      const { password } = await body(req);
      if (password === ADMIN_PASSWORD) return send(res, 200, { role: 'admin', token: makeToken('admin') });
      if (password === OPS_PASSWORD) return send(res, 200, { role: 'ops', token: makeToken('ops') });
      return send(res, 401, { error: 'Wrong password.' });
    }
    if (url.pathname === '/api/state' && req.method === 'GET') {
      const out = { role: roleOf(req) };
      for (const c of COLS) out[c] = Object.fromEntries(db.prepare(`SELECT id,data FROM ${c}`).all().map(r => [r.id, JSON.parse(r.data)]));
      return send(res, 200, out);
    }
    const m = url.pathname.match(/^\/api\/(\w+)\/([\w\-.]+)$/);
    if (m && COLS.includes(m[1])) {
      const [, col, id] = m, role = roleOf(req);
      if (!canWrite(role, col)) return send(res, 403, { error: role === 'viewer' ? 'Sign in to edit.' : 'Only an Admin can change this.' });
      if (req.method === 'PUT') {
        const err = saveDoc(col, id, await body(req));
        return err ? send(res, 409, { error: err }) : send(res, 200, { ok: true });
      }
      if (req.method === 'DELETE') {
        db.prepare(`DELETE FROM ${col} WHERE id=?`).run(id);
        if (col === 'workshops') db.prepare('DELETE FROM slot WHERE workshop_id=?').run(id);
        return send(res, 200, { ok: true });
      }
    }
    // static frontend
    const f = path.join(__dirname, 'public', url.pathname === '/' ? 'index.html' : path.normalize(url.pathname).replace(/^(\.\.[\/\\])+/, ''));
    if (f.startsWith(path.join(__dirname, 'public')) && fs.existsSync(f) && fs.statSync(f).isFile()) {
      res.writeHead(200, { 'Content-Type': f.endsWith('.html') ? 'text/html; charset=utf-8' : 'application/octet-stream' });
      return fs.createReadStream(f).pipe(res);
    }
    send(res, 404, { error: 'Not found' });
  } catch (e) { send(res, 500, { error: String(e.message || e) }); }
});
server.listen(PORT, () => console.log('Workshop planner running on http://localhost:' + PORT));
